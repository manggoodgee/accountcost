import React, { useState } from 'react';

export default function Home() {
  const [isRunning, setIsRunning] = useState(false);

  const startAutomation = () => {
    setIsRunning(true);
    fetch("https://hook.us2.make.com/drkjb28qsii98lydkl3sc15avp93g99v", {
      method: "POST",
      body: JSON.stringify({ command: "start" }),
    });
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>SmartBroker AI</h1>
      <p>ระบบอัตโนมัตินายหน้าอัจฉริยะ สร้างรายได้แทนคุณ 100%</p>
      <button onClick={startAutomation} style={{ padding: 10, marginTop: 20 }}>
        {isRunning ? "กำลังทำงาน..." : "เริ่มระบบอัตโนมัติ"}
      </button>
    </div>
  );
}